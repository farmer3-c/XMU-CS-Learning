#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <SOIL2/soil2.h>
#include <string>
#include <iostream>
#include <fstream>
#include <cmath>
#include <glm/glm.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include "Sphere.h"
#include "Utils.h"
#include "ImportedModel.h"
using namespace std;

#define numVAOs 2  // One for spheres, one for shuttle
#define numVBOs 6  // 3 for spheres (pos, tex, norm), 3 for shuttle

float cameraX, cameraY, cameraZ;
float sphLocX, sphLocY, sphLocZ;
GLuint renderingProgram;
GLuint vao[numVAOs];
GLuint vbo[numVBOs];
GLuint earthTexture, sunTexture, moonTexture, shuttleTexture;
float rotAmt = 0.0f;
float sunRotAmt = 0.0f;
ImportedModel myModel("shuttle.obj");

GLuint mvLoc, projLoc;
int width, height;
float aspect;
glm::mat4 pMat, vMat, mMat, mvMat;

Sphere mySphere = Sphere(48);  // For Earth
Sphere sunSphere = Sphere(48); // For Sun
Sphere moonSphere = Sphere(48); // For Moon

void setupVertices(void) {
    // --- Setup for Spheres (Sun, Earth, Moon) ---
    std::vector<int> ind = mySphere.getIndices();
    std::vector<glm::vec3> vert = mySphere.getVertices();
    std::vector<glm::vec2> tex = mySphere.getTexCoords();
    std::vector<glm::vec3> norm = mySphere.getNormals();

    std::vector<float> pvalues;
    std::vector<float> tvalues;
    std::vector<float> nvalues;

    int numIndices = mySphere.getNumIndices();
    for (int i = 0; i < numIndices; i++) {
        pvalues.push_back((vert[ind[i]]).x);
        pvalues.push_back((vert[ind[i]]).y);
        pvalues.push_back((vert[ind[i]]).z);
        tvalues.push_back((tex[ind[i]]).s);
        tvalues.push_back((tex[ind[i]]).t);
        nvalues.push_back((norm[ind[i]]).x);
        nvalues.push_back((norm[ind[i]]).y);
        nvalues.push_back((norm[ind[i]]).z);
    }

    glGenVertexArrays(1, &vao[0]); // VAO for spheres
    glBindVertexArray(vao[0]);
    glGenBuffers(3, vbo); // First 3 VBOs for spheres

    glBindBuffer(GL_ARRAY_BUFFER, vbo[0]);
    glBufferData(GL_ARRAY_BUFFER, pvalues.size() * 4, &pvalues[0], GL_STATIC_DRAW);

    glBindBuffer(GL_ARRAY_BUFFER, vbo[1]);
    glBufferData(GL_ARRAY_BUFFER, tvalues.size() * 4, &tvalues[0], GL_STATIC_DRAW);

    glBindBuffer(GL_ARRAY_BUFFER, vbo[2]);
    glBufferData(GL_ARRAY_BUFFER, nvalues.size() * 4, &nvalues[0], GL_STATIC_DRAW);

    // --- Setup for Shuttle ---
    std::vector<glm::vec3> shuttleVert = myModel.getVertices();
    std::vector<glm::vec2> shuttleTex = myModel.getTextureCoords();
    std::vector<glm::vec3> shuttleNorm = myModel.getNormals();

    std::vector<float> shuttlePvalues;
    std::vector<float> shuttleTvalues;
    std::vector<float> shuttleNvalues;

    int numShuttleVerts = myModel.getNumVertices();
    for (int i = 0; i < numShuttleVerts; i++) {
        shuttlePvalues.push_back(shuttleVert[i].x);
        shuttlePvalues.push_back(shuttleVert[i].y);
        shuttlePvalues.push_back(shuttleVert[i].z);
        shuttleTvalues.push_back(shuttleTex[i].s);
        shuttleTvalues.push_back(shuttleTex[i].t);
        shuttleNvalues.push_back(shuttleNorm[i].x);
        shuttleNvalues.push_back(shuttleNorm[i].y);
        shuttleNvalues.push_back(shuttleNorm[i].z);
    }

    glGenVertexArrays(1, &vao[1]); // VAO for shuttle
    glBindVertexArray(vao[1]);
    glGenBuffers(3, &vbo[3]); // Last 3 VBOs for shuttle

    glBindBuffer(GL_ARRAY_BUFFER, vbo[3]);
    glBufferData(GL_ARRAY_BUFFER, shuttlePvalues.size() * 4, &shuttlePvalues[0], GL_STATIC_DRAW);

    glBindBuffer(GL_ARRAY_BUFFER, vbo[4]);
    glBufferData(GL_ARRAY_BUFFER, shuttleTvalues.size() * 4, &shuttleTvalues[0], GL_STATIC_DRAW);

    glBindBuffer(GL_ARRAY_BUFFER, vbo[5]);
    glBufferData(GL_ARRAY_BUFFER, shuttleNvalues.size() * 4, &shuttleNvalues[0], GL_STATIC_DRAW);
}

void init(GLFWwindow* window) {
    renderingProgram = Utils::createShaderProgram("vertShader.glsl", "fragShader.glsl");
    cameraX = 0.0f; cameraY = 0.0f; cameraZ = 2.0f;
    sphLocX = 0.0f; sphLocY = 0.0f; sphLocZ = -1.0f;

    glfwGetFramebufferSize(window, &width, &height);
    aspect = (float)width / (float)height;
    pMat = glm::perspective(1.0472f, aspect, 0.1f, 1000.0f);

    setupVertices();
    earthTexture = Utils::loadTexture("earth.jpg");
    sunTexture = Utils::loadTexture("sunmap.jpg");
    moonTexture = Utils::loadTexture("moon.jpg");
    shuttleTexture = Utils::loadTexture("spstob_1.jpg");
}

void display(GLFWwindow* window, double currentTime) {
    glClear(GL_DEPTH_BUFFER_BIT);
    glClearColor(0.0, 0.0, 0.0, 1.0);
    glClear(GL_COLOR_BUFFER_BIT);

    glUseProgram(renderingProgram);

    mvLoc = glGetUniformLocation(renderingProgram, "mv_matrix");
    projLoc = glGetUniformLocation(renderingProgram, "proj_matrix");

    vMat = glm::translate(glm::mat4(1.0f), glm::vec3(-cameraX, -cameraY, -cameraZ));

    // --- Render the Sun ---
    sunRotAmt += 0.002f;
    if (sunRotAmt > 360.0f) sunRotAmt -= 360.0f;

    glm::mat4 sunMat = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.0f, 0.0f));
    sunMat = glm::rotate(sunMat, sunRotAmt, glm::vec3(0.0f, 1.0f, 0.0f));
    sunMat = glm::scale(sunMat, glm::vec3(0.5f, 0.5f, 0.5f));
    mvMat = vMat * sunMat;

    glUniformMatrix4fv(mvLoc, 1, GL_FALSE, glm::value_ptr(mvMat));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(pMat));

    glBindVertexArray(vao[0]); // Use sphere VAO
    glBindBuffer(GL_ARRAY_BUFFER, vbo[0]);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, 0);
    glEnableVertexAttribArray(0);

    glBindBuffer(GL_ARRAY_BUFFER, vbo[1]);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 0, 0);
    glEnableVertexAttribArray(1);

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, sunTexture);

    glEnable(GL_CULL_FACE);
    glFrontFace(GL_CCW);
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);
    glDrawArrays(GL_TRIANGLES, 0, sunSphere.getNumIndices());

    // --- Render the Earth ---
    rotAmt += 0.01f;
    if (rotAmt > 360.0f) rotAmt -= 360.0f;

    float radius = 1.0f;
    float earthX = radius * cos(currentTime);
    float earthZ = radius * sin(currentTime);

    mMat = glm::translate(glm::mat4(1.0f), glm::vec3(earthX, sphLocY, earthZ));
    mMat = glm::rotate(mMat, glm::radians(60.0f), glm::vec3(1.0f, 0.0f, 0.0f));
    mMat = glm::rotate(mMat, rotAmt, glm::vec3(0.0f, 1.0f, 0.0f));
    mMat = glm::scale(mMat, glm::vec3(0.1f, 0.1f, 0.1f));
    mvMat = vMat * mMat;

    glUniformMatrix4fv(mvLoc, 1, GL_FALSE, glm::value_ptr(mvMat));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(pMat));

    glBindVertexArray(vao[0]); // Use sphere VAO
    glBindBuffer(GL_ARRAY_BUFFER, vbo[0]);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, 0);
    glEnableVertexAttribArray(0);

    glBindBuffer(GL_ARRAY_BUFFER, vbo[1]);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 0, 0);
    glEnableVertexAttribArray(1);

    glBindTexture(GL_TEXTURE_2D, earthTexture);
    glDrawArrays(GL_TRIANGLES, 0, mySphere.getNumIndices());


    // --- Render the Moon ---
    float moonRadius = 0.3f; // Adjust the radius as needed
    float moonX = moonRadius * cos(currentTime * 2.0); // Faster orbit
    float moonZ = moonRadius * sin(currentTime * 2.0); // Faster orbit

    // Define the tilt angle in radians
    float tiltAngle = glm::radians(30.0f); // Adjust the tilt angle as needed

    // Create a rotation matrix for the tilt angle
    glm::mat4 tiltMat = glm::rotate(glm::mat4(1.0f), tiltAngle, glm::vec3(1.0f, 0.0f, 0.0f));

    // Apply the tilt matrix to the moon's position
    glm::vec4 tiltedMoonPos = tiltMat * glm::vec4(moonX, 0.0f, moonZ, 1.0f);

    glm::mat4 moonMat = glm::translate(glm::mat4(1.0f), glm::vec3(earthX + tiltedMoonPos.x, sphLocY + tiltedMoonPos.y, earthZ + tiltedMoonPos.z)); // Position moon relative to earth
    moonMat = glm::rotate(moonMat, glm::radians(60.0f), glm::vec3(1.0f, 0.0f, 0.0f)); // Rotate moon
    moonMat = glm::rotate(moonMat, rotAmt, glm::vec3(0.0f, 1.0f, 0.0f)); // Rotate moon
    moonMat = glm::scale(moonMat, glm::vec3(0.05f, 0.05f, 0.05f)); // Scale moon (adjust as needed)
    mvMat = vMat * moonMat;

    glUniformMatrix4fv(mvLoc, 1, GL_FALSE, glm::value_ptr(mvMat));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(pMat));

    glBindVertexArray(vao[0]); // Use sphere VAO
    glBindBuffer(GL_ARRAY_BUFFER, vbo[0]);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, 0);
    glEnableVertexAttribArray(0);

    glBindBuffer(GL_ARRAY_BUFFER, vbo[1]);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 0, 0);
    glEnableVertexAttribArray(1);

    glBindTexture(GL_TEXTURE_2D, moonTexture);
    glDrawArrays(GL_TRIANGLES, 0, moonSphere.getNumIndices());

    // --- Render the Shuttle ---
    float shuttleRadius = 1.5f; // Adjust the radius as needed
    float previousTime = currentTime - 0.01; // ǰһ֡��ʱ��
    float previousX = shuttleRadius * cos(previousTime);
    float previousZ = shuttleRadius * sin(previousTime);
    float shuttleX = shuttleRadius * cos(currentTime);
    float shuttleZ = shuttleRadius * sin(currentTime);

    float deltaX = previousX - shuttleX;
    float deltaZ = previousZ - shuttleZ;
    float angle = atan2(deltaX, deltaZ);

    glm::mat4 shuttleMat = glm::translate(glm::mat4(1.0f), glm::vec3(shuttleX, 0.0f, shuttleZ)); // Position shuttle
    shuttleMat = glm::rotate(shuttleMat, angle, glm::vec3(0.0f, 1.0f, 0.0f)); // Rotate shuttle to face forward
    shuttleMat = glm::scale(shuttleMat, glm::vec3(0.1f, 0.1f, 0.1f)); // Scale shuttle (adjust as needed)
    mvMat = vMat * shuttleMat;

    glUniformMatrix4fv(mvLoc, 1, GL_FALSE, glm::value_ptr(mvMat));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(pMat));

    glBindVertexArray(vao[1]); // Use shuttle VAO
    glBindBuffer(GL_ARRAY_BUFFER, vbo[3]);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, 0);
    glEnableVertexAttribArray(0);

    glBindBuffer(GL_ARRAY_BUFFER, vbo[4]);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 0, 0);
    glEnableVertexAttribArray(1);

    glBindTexture(GL_TEXTURE_2D, shuttleTexture);
    glDrawArrays(GL_TRIANGLES, 0, myModel.getNumVertices());
}
void window_size_callback(GLFWwindow* win, int newWidth, int newHeight) {
    aspect = (float)newWidth / (float)newHeight;
    glViewport(0, 0, newWidth, newHeight);
    pMat = glm::perspective(1.0472f, aspect, 0.1f, 1000.0f);
}

int main(void) {
    if (!glfwInit()) { exit(EXIT_FAILURE); }
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    GLFWwindow* window = glfwCreateWindow(600, 600, "Chapter 6 - program 1", NULL, NULL);
    glfwMakeContextCurrent(window);
    if (glewInit() != GLEW_OK) { exit(EXIT_FAILURE); }
    glfwSwapInterval(1);

    glfwSetWindowSizeCallback(window, window_size_callback);

    init(window);

    while (!glfwWindowShouldClose(window)) {
        display(window, glfwGetTime());
        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glfwDestroyWindow(window);
    glfwTerminate();
    exit(EXIT_SUCCESS);
}
