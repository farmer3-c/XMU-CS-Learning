#version 430

in vec2 tc;
out vec4 fragColor;

layout (binding = 0) uniform sampler2D s;

void main(void)
{
    fragColor = texture(s,tc);
}